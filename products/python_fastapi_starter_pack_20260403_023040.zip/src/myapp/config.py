from pydantic_settings import BaseSettings, SettingsConfigDict

class Settings(BaseSettings):
    database_url: str = "sqlite+aiosqlite:///./myapp.db"
    secret_key: str = "change-me-in-production"
    access_token_expire_minutes: int = 60 * 24

    model_config = SettingsConfigDict(env_file=".env")

settings = Settings()
