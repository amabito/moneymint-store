from fastapi import FastAPI
from myapp.routers import users, auth

app = FastAPI(title="MyApp", version="0.1.0")

app.include_router(auth.router)
app.include_router(users.router)

@app.get("/health")
async def health() -> dict:
    return {"status": "ok"}
