# Python FastAPI Starter Pack

Production-ready FastAPI scaffold: async endpoints, Pydantic v2 schemas, SQLAlchemy 2.0 async ORM, JWT auth, pytest fixtures, Docker + docker-compose, and GitHub Actions CI. Copy-paste and go.

## Setup

```bash
uv sync
uv run uvicorn src/myapp/main:app --reload
```

## Tests

```bash
uv run pytest -x -q
```
