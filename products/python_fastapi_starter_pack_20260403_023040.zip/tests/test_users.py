import pytest

@pytest.mark.asyncio
async def test_health(client):
    resp = await client.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}

@pytest.mark.asyncio
async def test_create_user(client):
    resp = await client.post("/users/", json={"email": "a@b.com", "password": "secret"})
    assert resp.status_code == 201
    data = resp.json()
    assert data["email"] == "a@b.com"
    assert "id" in data

@pytest.mark.asyncio
async def test_login_valid(client):
    await client.post("/users/", json={"email": "u@test.com", "password": "pass123"})
    resp = await client.post("/auth/login", data={"username": "u@test.com", "password": "pass123"})
    assert resp.status_code == 200
    assert "access_token" in resp.json()

@pytest.mark.asyncio
async def test_login_invalid(client):
    resp = await client.post("/auth/login", data={"username": "no@one.com", "password": "wrong"})
    assert resp.status_code == 401
